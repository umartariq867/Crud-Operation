# CRUD-Operation-in-PHP
CRUD - Create, Read, Update, Delete operation in database from a browser.
- Insertion operation  is also added.
- Added one button to delete every entry from database at once.
- Simple design.
- All operation working perfectly.

